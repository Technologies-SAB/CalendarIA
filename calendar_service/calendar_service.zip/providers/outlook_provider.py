import json
import datetime
import pytz
import logging
import time
from O365 import Account
from O365.utils import BaseTokenBackend
from config import settings
from security import decrypt_data

class SimpleTokenBackend(BaseTokenBackend):
    def __init__(self, token_dict: dict = None):
        super().__init__()
        self.token = token_dict

    def load_token(self):
        return self.token

    def save_token(self, token: dict):
        self.token = token
        return True
    
    def delete_token(self):
        self.token = None
        return True

    def is_expired(self) -> bool:
        if not self.token or 'expires_at' not in self.token:
            return True

        return self.token['expires_at'] <= time.time() + 300

def get_outlook_account_from_credentials(credentials: dict) -> Account:
    creds_tuple = (credentials['client_id'], credentials['client_secret'])
    token_backend = SimpleTokenBackend(token_dict=credentials.get('token'))
    account = Account(
            creds_tuple, 
            token_backend=token_backend,
            main_resource=credentials.get('username') # <-- USANDO O USERNAME
        )
    return account

def agendar_outlook(encrypted_credentials: str, data_str: str, hora_str: str, titulo: str, description: str):
    try:
        creds_json = decrypt_data(encrypted_credentials)
        credentials = json.loads(creds_json)
        account = get_outlook_account_from_credentials(credentials)

        account.username = credentials.get("username")

        print("Username:", account.username)

        if account.con.token_backend.is_expired():
            logging.warning("Token do Outlook expirou, tentando renovar...")
            if not account.con.refresh_token():
                return {
                    "status": "error",
                    "message": "Falha na renovação do token do Outlook. Por favor, reconecte sua conta."
                }
            logging.info("Token do Outlook renovado com sucesso.")

        schedule = account.schedule()
        calendars = schedule.list_calendars()
        
        if not calendars:
            return {"status": "error", "message": "Nenhum calendário foi encontrado nesta conta do Outlook."}
            
        calendar = schedule.get_default_calendar()
        if not calendar:
            calendar = calendars[0]

        new_event = calendar.new_event()
        new_event.subject = titulo
        new_event.body = description

        fuso_horario = pytz.timezone(settings.TIMEZONE)
        dia, mes, ano = map(int, data_str.split('/'))
        hora, minuto = map(int, hora_str.split(':'))
        start_time = fuso_horario.localize(datetime.datetime(ano, mes, dia, hora, minuto))
        end_time = start_time + datetime.timedelta(hours=1)
        
        new_event.start = start_time
        new_event.end = end_time
        new_event.save()
        
        logging.info(f"Evento '{titulo}' agendado com sucesso no Outlook.")
        return {"status": "success", "message": "Evento agendado com sucesso no Outlook."}

    except Exception as e:
        logging.error(f"ERRO AO AGENDAR NO OUTLOOK: {e}", exc_info=True)
        return {"status": "error", "message": f"Ocorreu um erro ao agendar no Outlook: {type(e).__name__}"}